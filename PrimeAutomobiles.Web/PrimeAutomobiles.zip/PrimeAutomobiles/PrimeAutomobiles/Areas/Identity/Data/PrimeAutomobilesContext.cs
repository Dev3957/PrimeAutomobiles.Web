﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Areas.Identity.Data;
using PrimeAutomobiles.Models;
using System.Reflection.Emit;

namespace PrimeAutomobiles.Areas.Identity.Data;

public class PrimeAutomobilesContext : IdentityDbContext<PrimeAutomobilesUser>
{
    public PrimeAutomobilesContext(DbContextOptions<PrimeAutomobilesContext> options)
        : base(options)
    {
    }

    // DbSet properties for each model
    public DbSet<Vehicle> Vehicles { get; set; }
    public DbSet<Customer> Customers { get; set; }
    public DbSet<ServiceRecord> ServiceRecords { get; set; }
    public DbSet<BillOfMaterial> BillOfMaterials { get; set; }
    public DbSet<ServiceRepresentative> ServiceRepresentatives { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        // Customize the ASP.NET Identity model and override the defaults if needed.
        // For example, you can rename the ASP.NET Identity table names and more.
        // Add your customizations after calling base.OnModelCreating(builder);

        // Define relationships and constraints

        /*   // Vehicle-Owner (Customer) Relationship
           modelBuilder.Entity<Vehicle>()
               .HasOne(v => v.Customer)
               .WithMany(c => c.Vehicles)
               .HasForeignKey(v => v.CustomerID)
               .OnDelete(DeleteBehavior.Restrict);*/

        /*     // ServiceRecord-Vehicle Relationship
             modelBuilder.Entity<ServiceRecord>()
                 .HasOne(sr => sr.Vehicle)
                 .WithMany(v => v.ServiceRecords)
                 .HasForeignKey(sr => sr.VehicleID)
                 .OnDelete(DeleteBehavior.Cascade);*/

        /*  // ServiceRecord-ServiceRepresentative Relationship
          modelBuilder.Entity<ServiceRecord>()
              .HasOne(sr => sr.ServiceRepresentative)
              .WithMany(sa => sa.ServiceRecords)
              .HasForeignKey(sr => sr.ServiceAdvisorID)
              .OnDelete(DeleteBehavior.Restrict);*/

        /*   // BillOfMaterial-ServiceRecord Relationship
           modelBuilder.Entity<BillOfMaterial>()
               .HasOne(bom => bom.ServiceRecord)
               .WithMany(sr => sr.BillOfMaterials)
               .HasForeignKey(bom => bom.ServiceID)
               .OnDelete(DeleteBehavior.Cascade);*/

        // Additional configuration for unique constraints (like VIN, Email, and Phone)
        modelBuilder.Entity<Vehicle>()
            .HasIndex(v => v.VIN)
        .IsUnique();

        modelBuilder.Entity<Customer>()
            .HasIndex(c => c.Phone)
        .IsUnique();

        modelBuilder.Entity<Customer>()
            .HasIndex(c => c.Email)
        .IsUnique();

        modelBuilder.Entity<ServiceRepresentative>()
            .HasIndex(sa => sa.Phone)
        .IsUnique();

        modelBuilder.Entity<ServiceRepresentative>()
            .HasIndex(sa => sa.Email)
            .IsUnique();
    }
}
