using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{
    
    public class CustomersController : Controller
    {
        private readonly ICustomerRepository _customerRepository ;

        public CustomersController(ICustomerRepository customerRepository) 
        {
            this._customerRepository = customerRepository ;
        }


        // GET: Customers/Index
        public async Task<IActionResult> Index()
        {
            var customers = await _customerRepository.GetAllCustomersAsync();
            return View(customers); // Returns the Index.cshtml view with a list of customers
        }

        // GET: Customers/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var customer = await _customerRepository.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer); // Returns the Details.cshtml view with the customer details
        }

        // GET: Customers/Create
        public IActionResult Create()
        {
            return View(); // Returns the Create.cshtml view
        }

        // POST: Customers/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("CustomerID,Name,Email,Phone,Address")] Customer customer)
        {
            if (ModelState.IsValid)
            {
                await _customerRepository.AddCustomerAsync(customer);
                return RedirectToAction(nameof(Index));
            }

            return View(customer); // If the model state is invalid, return the Create view with validation messages
        }

        // GET: Customers/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var customer = await _customerRepository.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer); // Returns the Edit.cshtml view with the customer data pre-filled
        }

        // POST: Customers/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("CustomerID,Name,Email,Phone,Address")] Customer customer)
        {
            if (id != customer.CustomerID)
            {
                return BadRequest("Customer ID mismatch.");
            }

            if (ModelState.IsValid)
            {
                await _customerRepository.UpdateCustomerAsync(customer);
                return RedirectToAction(nameof(Index));
            }

            return View(customer); // If the model state is invalid, return the Edit view with validation messages
        }

        // GET: Customers/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var customer = await _customerRepository.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            return View(customer); // Returns the Delete.cshtml view for confirmation
        }

        // POST: Customers/DeleteConfirmed
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var customer = await _customerRepository.GetCustomerByIdAsync(id);
            if (customer == null)
            {
                return NotFound();
            }

            await _customerRepository.DeleteCustomerAsync(id);
            return RedirectToAction(nameof(Index));
        }

    }
}
