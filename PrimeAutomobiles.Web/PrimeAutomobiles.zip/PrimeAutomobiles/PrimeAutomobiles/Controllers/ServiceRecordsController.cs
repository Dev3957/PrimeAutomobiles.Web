using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using PrimeAutomobiles.Repositories.Interfaces;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.ViewModels;
using Microsoft.AspNetCore.Mvc.Rendering;
using PrimeAutomobiles.Areas.Identity.Data;
using Microsoft.EntityFrameworkCore;

namespace PrimeAutomobiles.Controllers
{
    public class ServiceRecordsController : Controller
    {
        private readonly IServiceRecordRepository _serviceRecordRepository;
        private readonly IVehicleRepository _vehicleRepository;
        private readonly IServiceRepresentativeRepository _serviceRepresentativeRepository;
        private readonly PrimeAutomobilesContext _context;

        public ServiceRecordsController(
            IServiceRecordRepository serviceRecordRepository,
            IVehicleRepository vehicleRepository,
            IServiceRepresentativeRepository serviceRepresentativeRepository,
            PrimeAutomobilesContext context)
        {
            _serviceRecordRepository = serviceRecordRepository;
            _vehicleRepository = vehicleRepository;
            _serviceRepresentativeRepository = serviceRepresentativeRepository;
            _context = context;
        }

        // GET: ServiceRecords/Index
        public async Task<IActionResult> Index()
        {
            var serviceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(serviceRecords);
        }

        // GET: ServiceRecords/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var serviceRecord = await _serviceRecordRepository.GetServiceRecordByIdAsync(id);
            if (serviceRecord == null)
            {
                return NotFound();
            }

            return View(serviceRecord);
        }

        // GET: ServiceRecords/Create
        public async Task<IActionResult> Create()
        {
            var viewModel = await PopulateVehiclesAndServiceRepresentativesViewModel();
            
            return View(viewModel);
        }




        // POST: ServiceRecords/Create
        // POST: ServiceRecords/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ServiceID,VehicleID,ServiceDate,ServiceAdvisorID,Status")] ServiceRecord serviceRecord)
        {
            if (ModelState.IsValid)
            {
                await _serviceRecordRepository.AddServiceRecordAsync(serviceRecord);
                return RedirectToAction(nameof(Index));
            }

            var viewModel = await PopulateVehiclesAndServiceRepresentativesViewModel(serviceRecord.VehicleID, serviceRecord.ServiceAdvisorID);
            return View(viewModel);
        }


        // GET: ServiceRecords/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var serviceRecord = await _serviceRecordRepository.GetServiceRecordByIdAsync(id);
            if (serviceRecord == null)
            {
                return NotFound();
            }

            var viewModel = await PopulateVehiclesAndServiceRepresentativesViewModel(serviceRecord.VehicleID, serviceRecord.ServiceAdvisorID);
            viewModel.ServiceRecord = serviceRecord;
            return View(viewModel);
        }

        // POST: ServiceRecords/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ServiceID,VehicleID,ServiceDate,ServiceAdvisorID,Status")] ServiceRecord serviceRecord)
        {
            if (id != serviceRecord.ServiceID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _serviceRecordRepository.UpdateServiceRecordAsync(serviceRecord);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await ServiceRecordExists(serviceRecord.ServiceID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            var viewModel = await PopulateVehiclesAndServiceRepresentativesViewModel(serviceRecord.VehicleID, serviceRecord.ServiceAdvisorID);
            viewModel.ServiceRecord = serviceRecord;
            return View(viewModel);
        }

        // GET: ServiceRecords/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var serviceRecord = await _serviceRecordRepository.GetServiceRecordByIdAsync(id);
            if (serviceRecord == null)
            {
                return NotFound();
            }

            return View(serviceRecord);
        }

        // POST: ServiceRecords/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _serviceRecordRepository.DeleteServiceRecordAsync(id);
            return RedirectToAction(nameof(Index));
        }

        // Method to populate the ViewModel with vehicles and service representatives
        private async Task<ServiceRecordViewModel> PopulateVehiclesAndServiceRepresentativesViewModel(object selectedVehicle = null, object selectedServiceRepresentative = null)
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            var serviceRepresentatives = await _serviceRepresentativeRepository.GetAllServiceRepresentativesAsync();

            return new ServiceRecordViewModel
            {
                Vehicles = new SelectList(vehicles, "VehicleID", "Model", selectedVehicle),
                ServiceRepresentatives = new SelectList(serviceRepresentatives, "ServiceAdvisorID", "Name", selectedServiceRepresentative)
            };
        }
        private async Task<bool> ServiceRecordExists(int id)
        {
            var serviceRecord = await _serviceRecordRepository.GetServiceRecordByIdAsync(id);
            return serviceRecord != null;
        }
    }
}
