﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using PrimeAutomobiles.ViewModels;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{

    public class AdminController : Controller
    {
        private readonly IServiceRecordRepository _serviceRecordRepository;
        private readonly IVehicleRepository _vehicleRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IServiceRepresentativeRepository _serviceRepresentativeRepository;
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;

        public AdminController(
            IServiceRecordRepository serviceRecordRepository,
            IVehicleRepository vehicleRepository,
            ICustomerRepository customerRepository,
            IServiceRepresentativeRepository serviceRepresentativeRepository,
            IBillOfMaterialRepository billOfMaterialRepository)
        {
            _serviceRecordRepository = serviceRecordRepository;
            _vehicleRepository = vehicleRepository;
            _customerRepository = customerRepository;
            _serviceRepresentativeRepository = serviceRepresentativeRepository;
            _billOfMaterialRepository = billOfMaterialRepository;
        }
        
        // GET: Admin/Index
        public async Task<IActionResult> Index()
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            var serviceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();

            var vehicleIdsDueForService = serviceRecords
                .Where(sr => sr.Status == "Due for Servicing")
                .Select(sr => sr.VehicleID)
                .Distinct();

            var vehicleIdsUnderServicing = serviceRecords
                .Where(sr => sr.Status == "Currently Under Servicing")
                .Select(sr => sr.VehicleID)
                .Distinct();

            var vehicleIdsServiced = serviceRecords
                .Where(sr => sr.Status == "Serviced Vehicles")
                .Select(sr => sr.VehicleID)
                .Distinct();

            var viewModel = new AdminViewModel
            {
                VehiclesCount = vehicles.Count(),
                CustomersCount = await _customerRepository.CountAsync(),
                ServiceRecordsCount = await _serviceRecordRepository.CountAsync(),
                BillOfMaterialsCount = await _billOfMaterialRepository.CountAsync(),
                ServiceRepresentativesCount = await _serviceRepresentativeRepository.CountAsync(),
                DueForServiceVehicles = vehicles.Where(v => vehicleIdsDueForService.Contains(v.VehicleID)).ToList(),
                UnderServicingVehicles = vehicles.Where(v => vehicleIdsUnderServicing.Contains(v.VehicleID)).ToList(),
                ServicedVehicles = vehicles.Where(v => vehicleIdsServiced.Contains(v.VehicleID)).ToList()
            };

            return View(viewModel);
        }
        // GET: Admin/Vehicles
        public async Task<IActionResult> Vehicles()
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            return View(vehicles);
        }

        // GET: Admin/Customers
        public async Task<IActionResult> Customers()
        {
            var customers = await _customerRepository.GetAllCustomersAsync();
            return View(customers);
        }

        // GET: Admin/ServiceRecords
        public async Task<IActionResult> ServiceRecords()
        {
            var serviceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(serviceRecords);
        }

        // GET: Admin/BillOfMaterials
        public async Task<IActionResult> BillOfMaterials()
        {
            var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
            return View(billOfMaterials);
        }

        // GET: Admin/ServiceRepresentatives
        public async Task<IActionResult> ServiceRepresentatives()
        {
            var serviceRepresentatives = await _serviceRepresentativeRepository.GetAllServiceRepresentativesAsync();
            return View(serviceRepresentatives);
        }


        // Additional administrative actions like create, edit, and delete can be added here as needed.
    }
}
