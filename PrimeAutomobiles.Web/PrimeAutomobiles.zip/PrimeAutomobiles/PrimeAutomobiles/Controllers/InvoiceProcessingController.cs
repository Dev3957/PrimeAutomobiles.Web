﻿using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Repositories.Interfaces;
using PrimeAutomobiles.ViewModels;
using System.Linq;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{
    public class InvoiceProcessingController : Controller
    {
        private readonly IServiceRecordRepository _serviceRecordRepository;
        private readonly IVehicleRepository _vehicleRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IServiceRepresentativeRepository _serviceRepresentativeRepository;
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;

        public InvoiceProcessingController(
            IServiceRecordRepository serviceRecordRepository,
            IVehicleRepository vehicleRepository,
            ICustomerRepository customerRepository,
            IServiceRepresentativeRepository serviceRepresentativeRepository,
            IBillOfMaterialRepository billOfMaterialRepository)
        {
            _serviceRecordRepository = serviceRecordRepository;
            _vehicleRepository = vehicleRepository;
            _customerRepository = customerRepository;
            _serviceRepresentativeRepository = serviceRepresentativeRepository;
            _billOfMaterialRepository = billOfMaterialRepository;
        }

        // Method to list all serviced vehicles
        /*        public async Task<IActionResult> ServicedVehicles()
                {
                    var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
                    var serviceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();

                    // Get the Vehicle IDs for vehicles that are "Serviced"
                    var vehicleIdsServiced = serviceRecords
                        .Where(sr => sr.Status == "Serviced Vehicles")
                        .Select(sr => sr.VehicleID)
                        .Distinct();

                    // Filter the vehicles based on the serviced vehicle IDs
                    var servicedVehicles = vehicles.Where(v => vehicleIdsServiced.Contains(v.VehicleID)).ToList();

                    return View(servicedVehicles);
                }*/
        public async Task<IActionResult> ServicedVehicles()
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            var serviceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();

            // Get the Vehicle IDs for vehicles that are "Serviced"
            var servicedVehicleRecords = serviceRecords
                .Where(sr => sr.Status == "Serviced Vehicles")
                .Select(sr => new { sr.VehicleID, sr.ServiceID })
                .Distinct();

            // Filter the vehicles based on the serviced vehicle IDs and create the view model list
            var servicedVehicles = vehicles
                .Where(v => servicedVehicleRecords.Any(sv => sv.VehicleID == v.VehicleID))
                .Select(v => new ServicedVehicleViewModel
                {
                    VehicleID = v.VehicleID,
                    Make = v.Make,
                    Model = v.Model,
                    VIN = v.VIN,
                    Year = v.Year,
                    ServiceID = servicedVehicleRecords.First(sv => sv.VehicleID == v.VehicleID).ServiceID
                })
                .ToList();

            return View(servicedVehicles);
        }
        // Method to process the invoice
        public async Task<IActionResult> ProcessInvoice(int serviceId)
        {
            var serviceRecord = await _serviceRecordRepository.GetByIdAsync(serviceId);
            if (serviceRecord == null)
            {
                return NotFound();
            }

            var vehicle = await _vehicleRepository.GetByIdAsync(serviceRecord.VehicleID);
            var customer = await _customerRepository.GetByIdAsync(vehicle.CustomerID);
            var serviceAdvisor = await _serviceRepresentativeRepository.GetByIdAsync(serviceRecord.ServiceAdvisorID);
            var billOfMaterials = await _billOfMaterialRepository.GetBillOfMaterialsByServiceIdAsync(serviceId);

            var totalCost = billOfMaterials.Sum(bom => bom.Cost * bom.Quantity);

            var invoiceViewModel = new InvoiceViewModel
            {
                ServiceID = serviceRecord.ServiceID,
                CustomerName = customer.Name,
                CustomerAddress = customer.Address,
                CustomerPhone = customer.Phone,
                VehicleMake = vehicle.Make,
                VehicleModel = vehicle.Model,
                VIN = vehicle.VIN,
                ServiceDate = serviceRecord.ServiceDate,
                ServiceAdvisorName = serviceAdvisor.Name,
                BillOfMaterials = billOfMaterials.ToList(),
                TotalCost = totalCost
            };

            return View("Invoice", invoiceViewModel);
        }
    }
}
