using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{
    public class ServiceRepresentativesController : Controller
    {
        private readonly IServiceRepresentativeRepository _serviceRepresentativeRepository;

        public ServiceRepresentativesController(IServiceRepresentativeRepository serviceRepresentativeRepository)
        {
            _serviceRepresentativeRepository = serviceRepresentativeRepository;
        }

        // GET: ServiceRepresentatives/Index
        public async Task<IActionResult> Index()
        {
            var representatives = await _serviceRepresentativeRepository.GetAllServiceRepresentativesAsync();
            return View(representatives); // Returns the Index.cshtml view with a list of service representatives
        }

        // GET: ServiceRepresentatives/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var representative = await _serviceRepresentativeRepository.GetServiceRepresentativeByIdAsync(id);
            if (representative == null)
            {
                return NotFound();
            }

            return View(representative); // Returns the Details.cshtml view with the service representative details
        }

        // GET: ServiceRepresentatives/Create
        public IActionResult Create()
        {
            return View(); // Returns the Create.cshtml view
        }

        // POST: ServiceRepresentatives/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ServiceAdvisorID,Name,Email,Phone")] ServiceRepresentative representative)
        {
            if (ModelState.IsValid)
            {
                await _serviceRepresentativeRepository.AddServiceRepresentativeAsync(representative);
                return RedirectToAction(nameof(Index));
            }

            return View(representative); // If the model state is invalid, return the Create view with validation messages
        }

        // GET: ServiceRepresentatives/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var representative = await _serviceRepresentativeRepository.GetServiceRepresentativeByIdAsync(id);
            if (representative == null)
            {
                return NotFound();
            }

            return View(representative); // Returns the Edit.cshtml view with the service representative data pre-filled
        }

        // POST: ServiceRepresentatives/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ServiceAdvisorID,Name,Email,Phone")] ServiceRepresentative representative)
        {
            if (id != representative.ServiceAdvisorID)
            {
                return BadRequest("Service Representative ID mismatch.");
            }

            if (ModelState.IsValid)
            {
                await _serviceRepresentativeRepository.UpdateServiceRepresentativeAsync(representative);
                return RedirectToAction(nameof(Index));
            }

            return View(representative); // If the model state is invalid, return the Edit view with validation messages
        }

        // GET: ServiceRepresentatives/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var representative = await _serviceRepresentativeRepository.GetServiceRepresentativeByIdAsync(id);
            if (representative == null)
            {
                return NotFound();
            }

            return View(representative); // Returns the Delete.cshtml view for confirmation
        }

        // POST: ServiceRepresentatives/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _serviceRepresentativeRepository.DeleteServiceRepresentativeAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
