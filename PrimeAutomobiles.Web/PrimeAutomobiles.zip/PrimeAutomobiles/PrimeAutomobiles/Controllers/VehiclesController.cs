/*using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Web.Models;
using PrimeAutomobiles.Web.Repositories.Interfaces;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Web.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly IVehicleRepository _vehicleRepository;
        private readonly ICustomerRepository _customerRepository;

        public VehiclesController(IVehicleRepository vehicleRepository, ICustomerRepository customerRepository)
        {
            _vehicleRepository = vehicleRepository;
            _customerRepository = customerRepository;

        }

        // GET: Vehicles/Index
        public async Task<IActionResult> Index()
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            return View(vehicles); // Returns the Index.cshtml view with a list of vehicles
        }

        // GET: Vehicles/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle); // Returns the Details.cshtml view with vehicle details
        }

        // GET: Vehicles/Create
        public IActionResult Create()
        {
            return View(); // Returns the Create.cshtml view
        }

        // POST: Vehicles/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VehicleID,Make,Model,Year,VIN,CustomerID")] Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                await _vehicleRepository.AddVehicleAsync(vehicle);
                return RedirectToAction(nameof(Index));
            }

            return View(vehicle); // If the model state is invalid, return the Create view with validation messages
        }

        // GET: Vehicles/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle); // Returns the Edit.cshtml view with the vehicle data pre-filled
        }

        // POST: Vehicles/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VehicleID,Make,Model,Year,VIN,CustomerID")] Vehicle vehicle)
        {
            if (id != vehicle.VehicleID)
            {
                return BadRequest("Vehicle ID mismatch.");
            }

            if (ModelState.IsValid)
            {
                await _vehicleRepository.UpdateVehicleAsync(vehicle);
                return RedirectToAction(nameof(Index));
            }

            return View(vehicle); // If the model state is invalid, return the Edit view with validation messages
        }

        // GET: Vehicles/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle); // Returns the Delete.cshtml view for confirmation
        }

        // POST: Vehicles/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _vehicleRepository.DeleteVehicleAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
*/

using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Rendering;
using PrimeAutomobiles.Repositories.Interfaces;
using PrimeAutomobiles.Models; // Import for SelectListItem

namespace PrimeAutomobiles.Controllers
{
    public class VehiclesController : Controller
    {
        private readonly IVehicleRepository _vehicleRepository;
        private readonly ICustomerRepository _customerRepository;

        public VehiclesController(IVehicleRepository vehicleRepository, ICustomerRepository customerRepository)
        {
            _vehicleRepository = vehicleRepository;
            _customerRepository = customerRepository;
        }

        // GET: Vehicles/Index
        public async Task<IActionResult> Index()
        {
            var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
            return View(vehicles);
        }

        // GET: Vehicles/Details/{id}
        public async Task<IActionResult> Details(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle);
        }

        // GET: Vehicles/Create
        public async Task<IActionResult> Create()
        {
            await PopulateCustomersDropDownList();
            return View();
        }

        // POST: Vehicles/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VehicleID,Make,Model,Year,VIN,CustomerID")] Vehicle vehicle)
        {
            if (ModelState.IsValid)
            {
                await _vehicleRepository.AddVehicleAsync(vehicle);
                return RedirectToAction(nameof(Index));
            }

            await PopulateCustomersDropDownList(vehicle.CustomerID);
            return View(vehicle);
        }

        // GET: Vehicles/Edit/{id}
        public async Task<IActionResult> Edit(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            await PopulateCustomersDropDownList(vehicle.CustomerID);
            return View(vehicle);
        }

        // POST: Vehicles/Edit/{id}
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VehicleID,Make,Model,Year,VIN,CustomerID")] Vehicle vehicle)
        {
            if (id != vehicle.VehicleID)
            {
                return BadRequest("Vehicle ID mismatch.");
            }

            if (ModelState.IsValid)
            {
                await _vehicleRepository.UpdateVehicleAsync(vehicle);
                return RedirectToAction(nameof(Index));
            }

            await PopulateCustomersDropDownList(vehicle.CustomerID);
            return View(vehicle);
        }

        // GET: Vehicles/Delete/{id}
        public async Task<IActionResult> Delete(int id)
        {
            var vehicle = await _vehicleRepository.GetVehicleByIdAsync(id);
            if (vehicle == null)
            {
                return NotFound();
            }

            return View(vehicle);
        }

        // POST: Vehicles/Delete/{id}
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _vehicleRepository.DeleteVehicleAsync(id);
            return RedirectToAction(nameof(Index));
        }

        // Method to populate the dropdown list of customers
        private async Task PopulateCustomersDropDownList(object selectedCustomer = null)
        {
            var customers = await _customerRepository.GetAllCustomersAsync();
            ViewBag.CustomerID = new SelectList(customers, "CustomerID", "Name", selectedCustomer);
        }
    }
}
