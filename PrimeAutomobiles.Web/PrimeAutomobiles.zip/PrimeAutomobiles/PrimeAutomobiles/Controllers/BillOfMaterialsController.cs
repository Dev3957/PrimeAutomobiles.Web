/*using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Web.Controllers
{
    public class BillOfMaterialsController : Controller
    {
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;

        public BillOfMaterialsController(IBillOfMaterialRepository billOfMaterialRepository)
        {
            _billOfMaterialRepository = billOfMaterialRepository;
        }

        // GET: BillOfMaterials
        public async Task<IActionResult> Index()
        {
            var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
            return View(billOfMaterials);
        }

        // GET: BillOfMaterials/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: BillOfMaterials/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (ModelState.IsValid)
            {
                await _billOfMaterialRepository.AddBillOfMaterialAsync(billOfMaterial);
                return RedirectToAction(nameof(Index));
            }
            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }
            return View(billOfMaterial);
        }

        // POST: BillOfMaterials/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (id != billOfMaterial.BOMID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _billOfMaterialRepository.UpdateBillOfMaterialAsync(billOfMaterial);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BillOfMaterialExists(billOfMaterial.BOMID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // POST: BillOfMaterials/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _billOfMaterialRepository.DeleteBillOfMaterialAsync(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> BillOfMaterialExists(int id)
        {
            return await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id) != null;
        }
    }
}
*/

using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Web.Controllers
{
    public class BillOfMaterialsController : Controller
    {
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;
        private readonly IServiceRecordRepository _serviceRecordRepository;

        public BillOfMaterialsController(IBillOfMaterialRepository billOfMaterialRepository, IServiceRecordRepository serviceRecordRepository)
        {
            _billOfMaterialRepository = billOfMaterialRepository;
            _serviceRecordRepository = serviceRecordRepository;
        }

        // GET: BillOfMaterials
        public async Task<IActionResult> Index()
        {
            var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
            return View(billOfMaterials);
        }

        // GET: BillOfMaterials/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View();
        }

        // POST: BillOfMaterials/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (ModelState.IsValid)
            {
                await _billOfMaterialRepository.AddBillOfMaterialAsync(billOfMaterial);
                return RedirectToAction(nameof(Index));
            }
            // Re-populate ViewBag.ServiceRecords in case of validation failure
            ViewBag.ServiceRecords = new SelectList(await _serviceRecordRepository.GetAllServiceRecordsAsync(), "ServiceID", "ServiceID", billOfMaterial.ServiceID);
            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }
            // Populate ViewBag.ServiceRecords for the dropdown list
            ViewBag.ServiceRecords = new SelectList(await _serviceRecordRepository.GetAllServiceRecordsAsync(), "ServiceID", "ServiceID", billOfMaterial.ServiceID);
            return View(billOfMaterial);
        }

        // POST: BillOfMaterials/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (id != billOfMaterial.BOMID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _billOfMaterialRepository.UpdateBillOfMaterialAsync(billOfMaterial);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BillOfMaterialExists(billOfMaterial.BOMID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            // Re-populate ViewBag.ServiceRecords in case of validation failure
            ViewBag.ServiceRecords = new SelectList(await _serviceRecordRepository.GetAllServiceRecordsAsync(), "ServiceID", "ServiceID", billOfMaterial.ServiceID);
            return View(billOfMaterial);
        }

        // GET: BillOfMaterials/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // POST: BillOfMaterials/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _billOfMaterialRepository.DeleteBillOfMaterialAsync(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> BillOfMaterialExists(int id)
        {
            return await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id) != null;
        }
    }
}
