﻿using Microsoft.AspNetCore.Mvc;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Diagnostics;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{
    public class ServiceAdvisorController : Controller
    {
        private readonly IVehicleRepository _vehicleRepository;
        private readonly ICustomerRepository _customerRepository;
        private readonly IServiceRepresentativeRepository _serviceRepresentativeRepository;
        private readonly IServiceRecordRepository _serviceRecordRepository;
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;

        public ServiceAdvisorController(
            IVehicleRepository vehicleRepository,
            ICustomerRepository customerRepository,
            IServiceRepresentativeRepository serviceRepresentativeRepository,
            IServiceRecordRepository serviceRecordRepository,
            IBillOfMaterialRepository billOfMaterialRepository)
        {
            _vehicleRepository = vehicleRepository;
            _customerRepository = customerRepository;
            _serviceRepresentativeRepository = serviceRepresentativeRepository;
            _serviceRecordRepository = serviceRecordRepository;
            _billOfMaterialRepository = billOfMaterialRepository;
        }

        // GET: Admin/Index
        public async Task<IActionResult> Index()
        {
            try
            {
                var viewModel = new AdminViewModel
                {
                    BillOfMaterialsCount = await _billOfMaterialRepository.CountAsync(),
                    // Add more properties to the ViewModel as needed
                };

                return View(viewModel);
            }
            catch (Exception ex)
            {
                // Log the exception and return an error view if necessary
                return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }

        // GET: Admin/Vehicles
        public async Task<IActionResult> Vehicles()
        {
            try
            {
                var vehicles = await _vehicleRepository.GetAllVehiclesAsync();
                return View(vehicles);
            }
            catch (Exception ex)
            {
                // Log the exception and return an error view if necessary
                return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }

        // GET: Admin/BillOfMaterials
        public async Task<IActionResult> BillOfMaterials()
        {
            try
            {
                var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
                return View(billOfMaterials);
            }
            catch (Exception ex)
            {
                // Log the exception and return an error view if necessary
                return View("Error", new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
            }
        }

        // Additional actions like Create, Edit, Delete can be added here as needed
    }
}
