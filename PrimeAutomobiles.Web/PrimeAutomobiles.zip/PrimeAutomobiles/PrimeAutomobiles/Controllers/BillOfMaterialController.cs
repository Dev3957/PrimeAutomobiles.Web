using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;

using System.Threading.Tasks;

namespace PrimeAutomobiles.Controllers
{
    public class BillOfMaterialController : Controller
    {
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;
        private readonly IServiceRecordRepository _serviceRecordRepository;

        public BillOfMaterialController(IBillOfMaterialRepository billOfMaterialRepository, IServiceRecordRepository serviceRecordRepository)
        {
            _billOfMaterialRepository = billOfMaterialRepository;
            _serviceRecordRepository = serviceRecordRepository;
        }

        // GET: BillOfMaterial
        public async Task<IActionResult> Index()
        {
            var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
            return View(billOfMaterials);
        }

        // GET: BillOfMaterial/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // GET: BillOfMaterial/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View();
        }

        // POST: BillOfMaterial/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (ModelState.IsValid)
            {
                await _billOfMaterialRepository.AddBillOfMaterialAsync(billOfMaterial);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }

        // GET: BillOfMaterial/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }

        // POST: BillOfMaterial/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (id != billOfMaterial.BOMID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _billOfMaterialRepository.UpdateBillOfMaterialAsync(billOfMaterial);
                    return RedirectToAction(nameof(Index));
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BillOfMaterialExists(billOfMaterial.BOMID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
            }

            // Re-populate ViewBag.ServiceRecords in case of validation failure
            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }


        // GET: BillOfMaterial/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // POST: BillOfMaterial/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _billOfMaterialRepository.DeleteBillOfMaterialAsync(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> BillOfMaterialExists(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            return billOfMaterial != null;
        }
    }
}





/*using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Web.Models;
using PrimeAutomobiles.Web.Repositories.Interfaces;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Web.Controllers
{
    public class BillOfMaterialController : Controller
    {
        private readonly IBillOfMaterialRepository _billOfMaterialRepository;
        private readonly IServiceRecordRepository _serviceRecordRepository;

        public BillOfMaterialController(IBillOfMaterialRepository billOfMaterialRepository, IServiceRecordRepository serviceRecordRepository)
        {
            _billOfMaterialRepository = billOfMaterialRepository;
            _serviceRecordRepository = serviceRecordRepository;
        }

        // GET: BillOfMaterial
        public async Task<IActionResult> Index()
        {
            var billOfMaterials = await _billOfMaterialRepository.GetAllBillOfMaterialsAsync();
            return View(billOfMaterials);
        }

        // GET: BillOfMaterial/Details/5
        public async Task<IActionResult> Details(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // GET: BillOfMaterial/Create
        public async Task<IActionResult> Create()
        {
            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View();
        }

        // POST: BillOfMaterial/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (ModelState.IsValid)
            {
                await _billOfMaterialRepository.AddBillOfMaterialAsync(billOfMaterial);
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }

        // GET: BillOfMaterial/Edit/5
        public async Task<IActionResult> Edit(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }

        // POST: BillOfMaterial/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("BOMID,ServiceID,Item,Quantity,Cost")] BillOfMaterial billOfMaterial)
        {
            if (id != billOfMaterial.BOMID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    await _billOfMaterialRepository.UpdateBillOfMaterialAsync(billOfMaterial);
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!await BillOfMaterialExists(billOfMaterial.BOMID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewBag.ServiceRecords = await _serviceRecordRepository.GetAllServiceRecordsAsync();
            return View(billOfMaterial);
        }

        // GET: BillOfMaterial/Delete/5
        public async Task<IActionResult> Delete(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            if (billOfMaterial == null)
            {
                return NotFound();
            }

            return View(billOfMaterial);
        }

        // POST: BillOfMaterial/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            await _billOfMaterialRepository.DeleteBillOfMaterialAsync(id);
            return RedirectToAction(nameof(Index));
        }

        private async Task<bool> BillOfMaterialExists(int id)
        {
            var billOfMaterial = await _billOfMaterialRepository.GetBillOfMaterialByIdAsync(id);
            return billOfMaterial != null;
        }
    }
}
*/