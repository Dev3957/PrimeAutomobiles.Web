﻿using System.Collections.Generic;
using System.Threading.Tasks;
using PrimeAutomobiles.Models;

namespace PrimeAutomobiles.Repositories.Interfaces
{
    public interface IBillOfMaterialRepository
    {
        Task<IEnumerable<BillOfMaterial>> GetAllBillOfMaterialsAsync();
        Task<BillOfMaterial> GetBillOfMaterialByIdAsync(int id);
        Task AddBillOfMaterialAsync(BillOfMaterial billOfMaterial);
        Task UpdateBillOfMaterialAsync(BillOfMaterial billOfMaterial);
        Task DeleteBillOfMaterialAsync(int id);
        Task<int> CountAsync();
        Task<List<BillOfMaterial>> GetBillOfMaterialsByServiceIdAsync(int serviceId);

    }
}
