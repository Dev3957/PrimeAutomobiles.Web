﻿using PrimeAutomobiles.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Repositories.Interfaces
{
    public interface IVehicleRepository
    {
        Task<IEnumerable<Vehicle>> GetAllVehiclesAsync();
        Task<Vehicle> GetVehicleByIdAsync(int id);
        Task AddVehicleAsync(Vehicle vehicle);
        Task UpdateVehicleAsync(Vehicle vehicle);
        Task DeleteVehicleAsync(int id);
        Task<int> CountAsync();
        Task<IEnumerable<Vehicle>> GetVehiclesByServiceStatusAsync(string status);
        Task<Vehicle> GetByIdAsync(int vehicleId);

    }
}
