﻿using PrimeAutomobiles.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Repositories.Interfaces
{
    public interface IServiceRecordRepository
    {
        Task<IEnumerable<ServiceRecord>> GetAllServiceRecordsAsync();
        Task<ServiceRecord> GetServiceRecordByIdAsync(int id);
        Task AddServiceRecordAsync(ServiceRecord serviceRecord);
        Task UpdateServiceRecordAsync(ServiceRecord serviceRecord);
        Task DeleteServiceRecordAsync(int id);
        Task<int> CountAsync();
        Task<ServiceRecord> GetByIdAsync(int serviceId);
    }
}
