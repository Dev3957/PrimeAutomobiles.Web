﻿using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Areas.Identity.Data;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Repositories
{
    public class CustomerRepository : ICustomerRepository
    {
        private readonly PrimeAutomobilesContext _context;

        public CustomerRepository(PrimeAutomobilesContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Customer>> GetAllCustomersAsync()
        {
            return await _context.Customers.ToListAsync();
        }

        public async Task<Customer> GetCustomerByIdAsync(int id)
        {
            return await _context.Customers
        .FirstOrDefaultAsync(c => c.CustomerID == id);
        }

        public async Task AddCustomerAsync(Customer customer)
        {
            await _context.Customers.AddAsync(customer);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateCustomerAsync(Customer customer)
        {
            _context.Customers.Update(customer);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteCustomerAsync(int id)
        {
            var customer = await _context.Customers.FindAsync(id);
            if (customer != null)
            {
                _context.Customers.Remove(customer);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<int> CountAsync()
        {
            return await _context.Customers.CountAsync();
        }
        public async Task<Customer> GetByIdAsync(int customerId)
        {
            return await _context.Customers
                .FirstOrDefaultAsync(c => c.CustomerID == customerId);
        }
    }
}
