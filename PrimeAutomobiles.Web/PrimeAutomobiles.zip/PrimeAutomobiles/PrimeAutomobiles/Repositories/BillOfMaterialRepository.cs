﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Areas.Identity.Data;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;

namespace PrimeAutomobiles.Repositories
{
    public class BillOfMaterialRepository : IBillOfMaterialRepository
    {
        private readonly PrimeAutomobilesContext _context;

        public BillOfMaterialRepository(PrimeAutomobilesContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BillOfMaterial>> GetAllBillOfMaterialsAsync()
        {
            return await _context.BillOfMaterials.ToListAsync();
        }

        public async Task<BillOfMaterial> GetBillOfMaterialByIdAsync(int id)
        {
            return await _context.BillOfMaterials.FirstOrDefaultAsync(bom => bom.BOMID == id);
        }

        public async Task AddBillOfMaterialAsync(BillOfMaterial billOfMaterial)
        {
            await _context.BillOfMaterials.AddAsync(billOfMaterial);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateBillOfMaterialAsync(BillOfMaterial billOfMaterial)
        {
            _context.BillOfMaterials.Update(billOfMaterial);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteBillOfMaterialAsync(int id)
        {
            var billOfMaterial = await _context.BillOfMaterials.FindAsync(id);
            if (billOfMaterial != null)
            {
                _context.BillOfMaterials.Remove(billOfMaterial);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<int> CountAsync()
        {
            return await _context.BillOfMaterials.CountAsync();
        }
        public async Task<List<BillOfMaterial>> GetBillOfMaterialsByServiceIdAsync(int serviceId)
        {
            return await _context.BillOfMaterials
                .Where(b => b.ServiceID == serviceId)
                .ToListAsync();
        }

    }
}
