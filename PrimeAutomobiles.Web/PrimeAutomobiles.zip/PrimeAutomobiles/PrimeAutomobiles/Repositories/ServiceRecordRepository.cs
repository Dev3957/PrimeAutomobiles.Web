﻿using Microsoft.EntityFrameworkCore;
using PrimeAutomobiles.Areas.Identity.Data;
using PrimeAutomobiles.Models;
using PrimeAutomobiles.Repositories.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PrimeAutomobiles.Repositories
{
    public class ServiceRecordRepository : IServiceRecordRepository
    {
        private readonly PrimeAutomobilesContext _context;

        public ServiceRecordRepository(PrimeAutomobilesContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<ServiceRecord>> GetAllServiceRecordsAsync()
        {
            return await _context.ServiceRecords
                .ToListAsync();
        }

        public async Task<ServiceRecord> GetServiceRecordByIdAsync(int id)
        {
            return await _context.ServiceRecords
                .FirstOrDefaultAsync(sr => sr.ServiceID == id);
        }

        public async Task AddServiceRecordAsync(ServiceRecord serviceRecord)
        {
            await _context.ServiceRecords.AddAsync(serviceRecord);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateServiceRecordAsync(ServiceRecord serviceRecord)
        {
            _context.ServiceRecords.Update(serviceRecord);
            await _context.SaveChangesAsync();
        }

        public async Task DeleteServiceRecordAsync(int id)
        {
            var serviceRecord = await _context.ServiceRecords.FindAsync(id);
            if (serviceRecord != null)
            {
                _context.ServiceRecords.Remove(serviceRecord);
                await _context.SaveChangesAsync();
            }
        }

        public async Task<int> CountAsync()
        {
            return await _context.ServiceRecords.CountAsync();
        }
        public async Task<ServiceRecord> GetByIdAsync(int serviceId)
        {
            return await _context.ServiceRecords
                .FirstOrDefaultAsync(sr => sr.ServiceID == serviceId);
        }


    }
}
