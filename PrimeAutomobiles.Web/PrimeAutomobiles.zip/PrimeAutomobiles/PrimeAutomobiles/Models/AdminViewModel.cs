﻿using PrimeAutomobiles.Models;
using System.Collections.Generic;

namespace PrimeAutomobiles.Models
{
    public class AdminViewModel
    {
        public int VehiclesCount { get; set; }
        public int CustomersCount { get; set; }
        public int ServiceRecordsCount { get; set; }
        public int BillOfMaterialsCount { get; set; }
        public int ServiceRepresentativesCount { get; set; }

        public List<Vehicle> DueForServiceVehicles { get; set; }
        public List<Vehicle> UnderServicingVehicles { get; set; }
        public List<Vehicle> ServicedVehicles { get; set; }
    }
}
