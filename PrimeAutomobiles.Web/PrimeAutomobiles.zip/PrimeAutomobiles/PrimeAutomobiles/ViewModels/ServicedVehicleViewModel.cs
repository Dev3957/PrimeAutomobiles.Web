﻿namespace PrimeAutomobiles.ViewModels
{
    public class ServicedVehicleViewModel
    {
        public int VehicleID { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public string VIN { get; set; }
        public int Year { get; set; }
        public int ServiceID { get; set; }
    }
}
