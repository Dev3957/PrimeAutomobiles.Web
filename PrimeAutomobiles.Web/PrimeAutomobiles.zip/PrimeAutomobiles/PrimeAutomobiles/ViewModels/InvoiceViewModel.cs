﻿using PrimeAutomobiles.Models;
using System;
using System.Collections.Generic;

namespace PrimeAutomobiles.ViewModels
{
    public class InvoiceViewModel
    {
        public int ServiceID { get; set; }
        public string CustomerName { get; set; }
        public string CustomerAddress { get; set; }
        public string CustomerPhone { get; set; }
        public string VehicleMake { get; set; }
        public string VehicleModel { get; set; }
        public string VIN { get; set; }
        public DateTime ServiceDate { get; set; }
        public string ServiceAdvisorName { get; set; }
        public List<BillOfMaterial> BillOfMaterials { get; set; }
        public decimal TotalCost { get; set; }
    }
}
