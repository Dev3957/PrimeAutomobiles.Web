﻿using System.Collections.Generic;
using PrimeAutomobiles.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PrimeAutomobiles.ViewModels
{
    public class ServiceRecordViewModel
    {
        public ServiceRecord ServiceRecord { get; set; }
        public SelectList Vehicles { get; set; }
        public SelectList ServiceRepresentatives { get; set; }
    }
}
