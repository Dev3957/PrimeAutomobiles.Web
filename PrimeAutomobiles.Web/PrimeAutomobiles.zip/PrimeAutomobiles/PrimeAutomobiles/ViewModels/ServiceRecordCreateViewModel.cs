﻿using System.Collections.Generic;
using PrimeAutomobiles.Models;

namespace PrimeAutomobiles.ViewModels
{
    public class ServiceRecordCreateViewModel
    {
        public List<Vehicle> Vehicles { get; set; }
        public List<ServiceRepresentative> ServiceRepresentatives { get; set; }
        public ServiceRecord ServiceRecord { get; set; } 
        // Add this line
    }
}
